﻿using UnityEngine;
using System.Collections;

public class state1collider : MonoBehaviour 
{
	void OnTriggerStay (Collider state1collider)
	{
		
	}

}
